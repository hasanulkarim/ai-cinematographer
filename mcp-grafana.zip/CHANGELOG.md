# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.0] - 2026-08-28

### Added

- Optional per-call `orgId` argument, where applicable, to target a Grafana organization, opt-in via the `--dynamic-multi-org` flag; also discovers proxied datasource tools across every org the credential can access. Tools that address no organization — documentation lookups, local config generation, static query examples — do not advertise it, since selecting one could not change their answer ([#943](https://github.com/grafana/mcp-grafana/pull/943))
- `user_info` tool reporting the current identity, whether it is a Grafana admin, and the organizations the credential can access (with roles) ([#943](https://github.com/grafana/mcp-grafana/pull/943))
- Incident custom fields support for creating and updating incidents with user-defined fields ([#1131](https://github.com/grafana/mcp-grafana/pull/1131))
- Grafana documentation tools backed by `mcp-doc-server` for querying Grafana product documentation ([#1116](https://github.com/grafana/mcp-grafana/pull/1116))
- `--disable-query` flag to disable all query tools, and raw-SQL query tools (ClickHouse, Snowflake, Athena, MSSQL, PostgreSQL) are now gated behind `--disable-write` by default ([#1085](https://github.com/grafana/mcp-grafana/pull/1085))
- `grafana_api_request` now supports POST to `/api/ds/query` when query tools are enabled, allowing datasource queries through the generic API tool ([#1125](https://github.com/grafana/mcp-grafana/pull/1125))

### Fixed

- `run_panel_query` now resolves `sqlstring`-type dashboard variables correctly ([#1132](https://github.com/grafana/mcp-grafana/pull/1132))
- Dashboard tool now describes structured panel targets (e.g. CloudWatch, Elasticsearch) instead of silently dropping them ([#1130](https://github.com/grafana/mcp-grafana/pull/1130))
- Proxied tools close non-published MCP clients before signaling readiness, preventing resource leaks during tool discovery ([#1128](https://github.com/grafana/mcp-grafana/pull/1128))

### Changed

- `get_panel_image` no longer declares its own `orgId` argument, using the per-call `orgId` injected into the native tools where an organization applies instead. The argument is therefore only advertised with `--dynamic-multi-org`, and without that flag a call passing `orgId` is rejected as an unknown argument. Renders still scope the organization with `targetOrgId` rather than `orgId`, so they do not change the user's active organization, and an organization fixed by `GRAFANA_ORG_ID` or the `X-Grafana-Org-Id` header now sets `targetOrgId` too.
- `get_panel_image` returns the dashboard deeplink only when it would open in the organization the image was rendered from, which now also accounts for an organization fixed on the connection rather than passed per call. A link cannot carry an organization safely — `?orgId=N` is intercepted by Grafana's `OrgRedirect` middleware, which persists the switch onto the viewer's user record — so for any other organization the image is returned without a deeplink (and without the MCP Apps panel-viewer fallback) rather than with one that can resolve to a different dashboard of the same UID.

## [1.2.0] - 2026-08-25

### Added

- `alerting_manage_silences` tool (opt-in, read/write-gated) to list, create, and expire Grafana alert silences ([#991](https://github.com/grafana/mcp-grafana/pull/991))
- `update_incident` tool to update fields on an existing incident ([#1080](https://github.com/grafana/mcp-grafana/pull/1080))
- `update_alert_group` tool to acknowledge and resolve Grafana OnCall alert groups ([#1083](https://github.com/grafana/mcp-grafana/pull/1083))
- `get_alert_group` now returns the last alert payload for the group, so callers can inspect the triggering alert without a second lookup ([#1081](https://github.com/grafana/mcp-grafana/pull/1081))
- Agent Observability `agento11y_manage_experiments` and `agento11y_manage_test_suites` tools, in the opt-in `agento11y` category ([#1062](https://github.com/grafana/mcp-grafana/pull/1062))
- Compact output format for `query_loki_logs`, reducing token usage for large log result sets ([#990](https://github.com/grafana/mcp-grafana/pull/990))
- Opt-in Loki query cost guardrail for `query_loki_logs` (`--loki-guardrail-mode` / `GRAFANA_LOKI_GUARDRAIL_MODE`, `off` by default, with `shadow` and `enforce` modes). Because Loki query cost is bytes *scanned* — determined only by the stream selector and time range, not line filters — the guardrail requires a selective stream selector, caps the time range (`--loki-guardrail-max-range`, default 24h), and pre-checks Loki's `index/stats` byte estimate against a budget (`--loki-guardrail-max-bytes`, default 100GiB). Blocked queries return an MCP tool error with rewrite guidance; unparseable queries fail open ([#1031](https://github.com/grafana/mcp-grafana/pull/1031))
- OpenTelemetry counters recording Loki cost-guardrail decisions (allowed, blocked, failed-open), so operators can observe the guardrail's impact ([#1095](https://github.com/grafana/mcp-grafana/pull/1095))
- `run_panel_query` now supports PostgreSQL ([#1112](https://github.com/grafana/mcp-grafana/pull/1112)) and MSSQL ([#1042](https://github.com/grafana/mcp-grafana/pull/1042)) datasources
- Datasource resolution falls back to `/api/frontend/settings` when the datasource metadata API is forbidden, so tools keep working on instances that restrict it ([#1015](https://github.com/grafana/mcp-grafana/pull/1015))
- `GrafanaVersion(ctx)` exposes the targeted Grafana version to tools, so they can gate behaviour on it instead of inferring capability from API versions ([#1091](https://github.com/grafana/mcp-grafana/pull/1091))
- Optional `orgId` parameter on `get_panel_image` to render a panel for a specific organisation ([#903](https://github.com/grafana/mcp-grafana/pull/903))
- `list_datasources` now supports filtering by name ([#973](https://github.com/grafana/mcp-grafana/pull/973))
- `--server-name` flag (and `GRAFANA_MCP_SERVER_NAME` env var) to set a custom MCP server name in the handshake and OTel `service.name`, so operators can distinguish multiple instances ([#1011](https://github.com/grafana/mcp-grafana/pull/1011))
- Scoped SOCKS5 egress proxy via `GRAFANA_SOCKS5_PROXY`, routing outbound Grafana traffic through a SOCKS5 proxy ([#1119](https://github.com/grafana/mcp-grafana/pull/1119))
- An MCP Bundle (`.mcpb`) for Claude Desktop is now built and attached on release ([#1077](https://github.com/grafana/mcp-grafana/pull/1077))

### Changed

- Bumped `mcp-go` from v0.55.0 to v0.58.0, picking up fixes for tool-filter scans on the `tools/call` hot path, raw JSON preservation for tool arguments and `structuredContent`, schema tags on nested fields, multi-line SSE `data` fields, and HEAD requests returning 200. This also inherits mcp-go's new default-on DNS rebinding protection, which returns 403 when a request arrives over a loopback connection with a non-loopback `Host` header — a second check underneath `DNSRebindingProtectionMiddleware` that `--allowed-hosts` cannot loosen. Default deployments are unaffected, since `DefaultAllowedHosts` already restricts `Host` to loopback variants; operators who widen `--allowed-hosts` while a same-host reverse proxy forwards over loopback preserving a non-localhost `Host` should configure the proxy to rewrite `Host` to localhost ([#1097](https://github.com/grafana/mcp-grafana/pull/1097))
- `tools.Stats.Bytes` is now `int64` (was `int`) so index/stats byte counts cannot overflow on 32-bit platforms; Go API consumers of the exported struct may need a cast ([#1031](https://github.com/grafana/mcp-grafana/pull/1031))
- `/api/frontend/settings` is now fetched once per Grafana instance instead of up to three times. The public URL, the Grafana version and the dashboard namespace previously each fetched that endpoint behind a cache of their own, even though a single response carries all three fields. `mcpgrafana.GrafanaClient` gains a `Version` field populated by the same request that populates `PublicURL`, and `mcpgrafana.GrafanaVersion` prefers it, so a tool holding a client reads the version with no HTTP request at all — previously it cost a blocking round trip on a detached context the caller could not cancel. The namespace keeps a separate org-keyed cache, because Grafana computes it for the requesting org and a URL-keyed entry would serve one org another org's namespace. Failed fetches are still retried rather than cached, but a *successful* fetch that simply omits `buildInfo` is now cached instead of being refetched on every call ([#1115](https://github.com/grafana/mcp-grafana/pull/1115))

### Fixed

- Closed two gaps in the `GRAFANA_SOCKS5_PROXY` egress guarantee. The `install_plugin` and `search_plugin_information` tools reached the grafana.com plugin catalog via `http.DefaultClient`, bypassing the configured SOCKS5 proxy entirely; these requests now route through the proxy (carrying no Grafana credentials or forwarded headers) and fail closed when it is misconfigured. `NewGrafanaClient` now installs a fail-closed transport instead of panicking when the proxy cannot be applied, matching the OnCall and incident paths, and the per-call fail-closed logic is centralised in one helper ([#1121](https://github.com/grafana/mcp-grafana/pull/1121))
- `observability.ToolMetricDimensions` now bounds the `mcp.tool.phase` metric label against the `toolMetricDims` allowlist, like `mcp.tool.operation` and `mcp.tool.resource_type`. Phase is read from a tool result's `_meta`, and results proxied from an MCP-enabled datasource come from a remote server rather than from this repo, so the label was unbounded-cardinality in the general case. A tool that does not opt into `phases` now contributes no phase, and an opted-in tool reporting an unexpected value reports `other`. Behaviour is unchanged for every in-tree tool: `create_datasource` is the only producer, with `schema` and `created` ([#1094](https://github.com/grafana/mcp-grafana/issues/1094))
- Distributed traces are no longer broken over the HTTP transports: the server now installs a global OTel `TextMapPropagator` (via `autoprop`, honouring `OTEL_PROPAGATORS`, default `tracecontext,baggage`), so an inbound `traceparent` continues the caller's trace and outbound Grafana API requests carry one of their own. Previously every hop started a disconnected trace. Trace context forwarded via `GRAFANA_FORWARD_HEADERS` no longer overrides the propagated value, which would have cut mcp-grafana out of the middle of the trace ([#1084](https://github.com/grafana/mcp-grafana/issues/1084))
- Grafana-managed alert rule UIDs are recovered from the internal `__alert_rule_uid__` / `__alert_rule_namespace_uid__` labels when older Grafana responses omit the top-level UID fields; those internal labels are stripped from the returned summary so they don't surface as user labels ([#968](https://github.com/grafana/mcp-grafana/pull/968))
- Alert rule matchers are now encoded in the JSON shape Grafana expects, fixing rule create/update requests that Grafana previously rejected ([#1111](https://github.com/grafana/mcp-grafana/pull/1111))
- `run_panel_query` now resolves constant and textbox dashboard variables from their query field, so panels using them return correct results ([#1041](https://github.com/grafana/mcp-grafana/pull/1041))
- Datasource queries fall back to the legacy proxy on a `401`, restoring queries against datasources the metadata proxy rejects ([#1022](https://github.com/grafana/mcp-grafana/pull/1022))
- URL shortening for navigation deeplinks now sends a relative path, fixing link generation on some deployments ([#974](https://github.com/grafana/mcp-grafana/pull/974))
- `GRAFANA_URL` is normalized where it enters the process (trailing slash trimmed, missing scheme supplied), so the config, API client, and client-cache key all agree on the target. Previously a schemeless value such as `127.0.0.1:3000` could panic at startup or produce hostless requests ([#1034](https://github.com/grafana/mcp-grafana/pull/1034))
- Proxied tools auto-wire `SetToolManager` and report a clearer error when the tool manager is nil ([#1102](https://github.com/grafana/mcp-grafana/pull/1102))
- The session wait when building a proxied tool set is now bounded, so a slow or unavailable datasource can no longer hang tool discovery ([#1087](https://github.com/grafana/mcp-grafana/pull/1087))
- Transient proxied-tool discovery/connect failures are retried and connections are established in parallel, making proxied tool startup faster and more resilient ([#1071](https://github.com/grafana/mcp-grafana/pull/1071))
- The client cache and session OTel meters are now injectable, so embedders can supply their own instrumentation ([#1073](https://github.com/grafana/mcp-grafana/pull/1073))

## [1.1.0] - 2026-08-10

### Added

- Optional bearer-token caller authentication for the SSE and streamable-http transports via `--server-auth-token` / `MCP_GRAFANA_SERVER_TOKEN`. When set, callers must present `Authorization: Bearer <token>` and unauthenticated requests are rejected with `401` before any tool runs. Caller authentication is enforced only when a token is configured; when it isn't, a non-loopback bind still starts but logs a security error at startup ([#1059](https://github.com/grafana/mcp-grafana/pull/1059), [#1060](https://github.com/grafana/mcp-grafana/pull/1060))
- `ask_assistant` tool (opt-in, write-gated) for asking Grafana Assistant open-ended questions and getting a full text reply ([#1026](https://github.com/grafana/mcp-grafana/pull/1026))
- Agent Observability tool `agento11y_manage_test_suites`, in the opt-in `agento11y` category. Reads cover the test suites that offline experiments run against, one suite with its full version history, and the test cases of one version. The write operations (create and update a suite; open a draft version; publish it; upsert and delete a test case) need `grafana-agento11y-app.eval:write` and are registered only when write tools are enabled. `upsert_test_case` replaces the whole case rather than merging into it, and a published version rejects every edit, so changing a published suite means opening a new draft
- Agent Observability tool `agento11y_manage_experiments`, in the opt-in `agento11y` category. Reads cover the experiment list and filter facets, one experiment with its headline result, a per-test-case report, an experiment's trials and scores, and one trial with its scores and artifact metadata. `get_report` is trimmed to `row_limit` rows (default 50, max 500) because the route is not paginated upstream and nests every test case input, score, and artifact record. The write operations (`update` and `cancel`) need `grafana-agento11y-app.eval:write` and are registered only when write tools are enabled. Creating experiments and trials is not exposed: the plugin proxy blocks those routes
- Agent Observability tool `agento11y_manage_agents`, in the opt-in `agento11y` category. Read-only: `list` for the agent catalog, `get` for one agent version in full (system prompt, tools, models), `list_versions` for an agent's version history, and `list_version_scores` for evaluation score aggregates per version. Needs `grafana-agento11y-app.data:read` and is registered whether or not write tools are enabled ([#1036](https://github.com/grafana/mcp-grafana/pull/1036))
- Agent Observability tool `agento11y_manage_eval_collections`, in the opt-in `agento11y` category. Reads cover saved conversations, the collections that group them, and the membership in both directions. The write operations (bookmark and delete a saved conversation; create, update, and delete a collection; add and remove collection members) need `grafana-agento11y-app.eval:write` and are registered only when write tools are enabled ([#1035](https://github.com/grafana/mcp-grafana/pull/1035))
- Agent Observability eval control-plane tools `agento11y_manage_evaluators` and `agento11y_manage_eval_rules`, in the opt-in `agento11y` category. Reads cover evaluators, evaluator templates, template versions, the judge provider and model catalog, eval rules, and guards. The write operations (evaluator upsert, fork, test, and delete; rule and guard create, update, preview, and delete) need `grafana-agento11y-app.eval:write` and are registered only when write tools are enabled ([#1028](https://github.com/grafana/mcp-grafana/pull/1028))
- CLI flags to include tool arguments in OpenTelemetry spans and to configure the Grafana client request timeout ([#1023](https://github.com/grafana/mcp-grafana/pull/1023))

### Fixed

- Declare `readOnly`/`destructive`/`openWorld` hints on every tool ([#1051](https://github.com/grafana/mcp-grafana/pull/1051))
- Proxied-tools memory scaling with session count and unbounded per-session tool-store growth ([#1001](https://github.com/grafana/mcp-grafana/pull/1001))
- Restrict the Prometheus backend to known Prometheus-compatible datasource types ([#1006](https://github.com/grafana/mcp-grafana/pull/1006))
- Respect `OTEL_LOGS_EXPORTER=none` to disable OTLP log export ([#1012](https://github.com/grafana/mcp-grafana/pull/1012))
- A `GRAFANA_URL` without a scheme is normalized where it enters the process, so the API client and the client cache resolve the same instance as the rest of the server. `GRAFANA_URL=127.0.0.1:3000` used to panic at startup, and a schemeless hostname produced requests with no host while tools built from `GrafanaConfig.URL` kept working ([#1034](https://github.com/grafana/mcp-grafana/pull/1034))

### Changed

- Enrich telemetry to include more tool dimensions ([#1016](https://github.com/grafana/mcp-grafana/pull/1016))
- `query_pyroscope` now returns a per-function table (`pprof -top` style: flat/cum per fully-qualified function name) by default instead of a line-level DOT call graph. The DOT call graph remains available via `format="dot"` and no longer deletes the `other` truncation node ([#1025](https://github.com/grafana/mcp-grafana/pull/1025))

### Removed

- Support for the undocumented `X-Grafana-URL` header ([#1052](https://github.com/grafana/mcp-grafana/pull/1052))

## [1.0.0] - 2026-07-28

### Added

- Agent Observability tools: `agento11y_manage_conversations` and `agento11y_manage_generations` in a new `agento11y` category, excluded from the default tool set ([#944](https://github.com/grafana/mcp-grafana/pull/944))
- Inline panel viewer for `get_panel_image` on [MCP Apps](https://modelcontextprotocol.io/)-aware hosts, with a dashboard deeplink fallback for other hosts. The deeplink text content is tagged with `_meta.ui.kind = "deeplink"` so viewers can locate it structurally instead of by string matching ([#882](https://github.com/grafana/mcp-grafana/pull/882))

### Fixed

- Enable OTLP trace export with the signal-specific `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` environment variable, so operators can ship traces without also exporting logs; the generic `OTEL_EXPORTER_OTLP_ENDPOINT` still enables both signals ([#1004](https://github.com/grafana/mcp-grafana/pull/1004))

### Changed

- Tool calls with unknown argument keys are now rejected with an error naming the unknown keys and listing the valid ones, instead of silently ignoring them and answering from default values ([#997](https://github.com/grafana/mcp-grafana/pull/997))

## [0.17.2] - 2026-07-13

### Security

- Bind environment-configured credentials to the configured Grafana URL. A URL supplied in the `X-Grafana-URL` request header no longer causes the environment service-account token, deprecated API key, basic auth, or extra headers to be sent to a caller-specified host ([#XXX](https://github.com/grafana/mcp-grafana/pull/XXX))

## [0.17.1] - 2026-07-07

### Fixed

- Send the relative path (rather than an absolute URL) to the short-urls API when generating navigation deeplinks ([#976](https://github.com/grafana/mcp-grafana/pull/976))

### Security

- Block DNS rebinding attacks on the HTTP and SSE transports ([#957](https://github.com/grafana/mcp-grafana/pull/957))

## [0.17.0] - 2026-06-23

### Added

- Datasource management tools for creating and updating datasources via the MCP server, gated behind write tools, with schema-guided configuration that follows each datasource type's JSON schema and excludes sensitive credential fields ([#939](https://github.com/grafana/mcp-grafana/pull/939))

### Fixed

- Recognize the Athena plugin's `rawSQL` query field when extracting dashboard panel queries ([#956](https://github.com/grafana/mcp-grafana/pull/956))

## [0.16.0] - 2026-06-16

### Added

- Snapshot tools (`list_snapshots`, `get_snapshot`, `create_snapshot`, `delete_snapshot`) for managing Grafana dashboard snapshots ([#949](https://github.com/grafana/mcp-grafana/pull/949))
- Native dashboard schema v2 support in the dashboard tools ([#937](https://github.com/grafana/mcp-grafana/pull/937))
- Quickwit datasource support ([#941](https://github.com/grafana/mcp-grafana/pull/941))
- BigQuery datasource support in `run_panel_query` ([#930](https://github.com/grafana/mcp-grafana/pull/930))
- Elasticsearch and OpenSearch tools now honor the datasource-configured `timeField` ([#909](https://github.com/grafana/mcp-grafana/pull/909))
- Relative time syntax (e.g. `now-1h`) for time range parameters across tools ([#942](https://github.com/grafana/mcp-grafana/pull/942))
- `GRAFANA_SERVICE_ACCOUNT_TOKEN_FILE` environment variable to read the service account token from a file, supporting rotated tokens ([#935](https://github.com/grafana/mcp-grafana/pull/935))
- Optional `startRfc3339`/`endRfc3339` time range parameters for `list_prometheus_metric_names` to restrict results to metrics active within a window ([#927](https://github.com/grafana/mcp-grafana/pull/927))
- `query_prometheus` now surfaces datasource `warnings` (e.g. partial responses from Thanos) in its result ([#946](https://github.com/grafana/mcp-grafana/pull/946))

### Fixed

- Elasticsearch client now refuses HTTP redirects that would drop the request body, preventing malformed queries against redirecting endpoints ([#951](https://github.com/grafana/mcp-grafana/pull/951))
- Propagate forwarded headers to downstream Loki calls by using the configured HTTP transport ([#945](https://github.com/grafana/mcp-grafana/pull/945))

## [0.15.2] - 2026-06-04

### Fixed

- Docker images are again published to `docker.io/grafana/mcp-grafana`. v0.15.0 and v0.15.1 Docker images were never published because the shared Docker Hub credential was restricted to read-only. The release workflow now publishes via Grafana's GAR-based Docker Hub mirror pipeline ([#925](https://github.com/grafana/mcp-grafana/pull/925))

## [0.15.1] - 2026-06-03

### Added

- `shorten_url` tool for creating Grafana short links from long dashboard or explore URLs ([#899](https://github.com/grafana/mcp-grafana/pull/899))
- Provisioning workflow tools: `list_provisioning_repositories` for discovering connected repositories, `validate_provisioning_file` for dry-run validation of provisioning files, and provisioning preview support in `get_panel_image` and `generate_deeplink` for rendering dashboards from PR branches before merge ([#900](https://github.com/grafana/mcp-grafana/pull/900))

### Changed

- Rendering tools now use a shared transport chain with `BaseTransport` support for consistent HTTP middleware ([#918](https://github.com/grafana/mcp-grafana/pull/918))

### Security

- Redact credentials from debug transport logs to prevent accidental exposure ([#920](https://github.com/grafana/mcp-grafana/pull/920))
- Update Go to 1.26.3 to fix CVE-2026-33810 and bump litellm dependency ([#916](https://github.com/grafana/mcp-grafana/pull/916))

## [0.15.0] - 2026-06-01

### Added

- Snowflake datasource tools for querying Snowflake through Grafana's `/api/ds/query` endpoint with macro substitution and template variables ([#845](https://github.com/grafana/mcp-grafana/pull/845))
- Amazon Athena datasource support with schema discovery tools and SQL query execution, including macro substitution and result reuse ([#799](https://github.com/grafana/mcp-grafana/pull/799))
- VictoriaLogs support through existing Loki tools, routing LogsQL queries via the VictoriaLogs HTTP API without adding new tools ([#850](https://github.com/grafana/mcp-grafana/pull/850))
- Loki label-strategy analyzer tools for evaluating label cardinality and optimization opportunities ([#885](https://github.com/grafana/mcp-grafana/pull/885))
- Plugin install and search tools for discovering, inspecting, and installing Grafana plugins ([#835](https://github.com/grafana/mcp-grafana/pull/835))

### Fixed

- Scope datasource fallback cache by request path to prevent incorrect cache hits across different API endpoints ([#897](https://github.com/grafana/mcp-grafana/pull/897))
- Release builds now report the correct version via ldflags injection ([#895](https://github.com/grafana/mcp-grafana/pull/895))
- Improved Loki and dashboard tool descriptions for better agent accuracy ([#880](https://github.com/grafana/mcp-grafana/pull/880))
- Add readResponseBody helper to limit and detect oversized responses, preventing excessive memory use ([#884](https://github.com/grafana/mcp-grafana/pull/884))
- Improved timeout error messages for proxied tools with context-aware logging ([#881](https://github.com/grafana/mcp-grafana/pull/881))
- Cap error response body reads to 1KB across all HTTP clients to prevent excessive memory allocation from misbehaving servers ([#876](https://github.com/grafana/mcp-grafana/pull/876))

### Changed

- Consolidated duplicated `/api/ds/query` implementations into a shared helper ([#877](https://github.com/grafana/mcp-grafana/pull/877))

### Security

- Update `golang.org/x/net` to v0.55.0 to address security vulnerability ([#901](https://github.com/grafana/mcp-grafana/pull/901))

## [0.14.0] - 2026-05-08

### Added

- Generic API request tool for making arbitrary HTTP requests to the Grafana API ([#841](https://github.com/grafana/mcp-grafana/pull/841))
- OpenSearch datasource support ([#669](https://github.com/grafana/mcp-grafana/pull/669))
- Tool to retrieve Grafana plugin information ([#826](https://github.com/grafana/mcp-grafana/pull/826))
- Export logs via OTLP when `OTEL_EXPORTER_OTLP_ENDPOINT` or `OTEL_EXPORTER_OTLP_LOGS_ENDPOINT` is set, consistent with existing OTLP trace export ([#839](https://github.com/grafana/mcp-grafana/pull/839))
- Configurable slow-request-threshold logging for identifying long-running tool calls ([#756](https://github.com/grafana/mcp-grafana/pull/756))
- Server instructions now dynamically reflect only the enabled tool categories, preventing agents from attempting to use disabled tools ([#829](https://github.com/grafana/mcp-grafana/pull/829))

### Fixed

- Route OnCall tools through IRM plugin proxy for correct on-behalf-of authentication ([#842](https://github.com/grafana/mcp-grafana/pull/842))
- Propagate context to jq operations and return clear errors on non-JSON input ([#847](https://github.com/grafana/mcp-grafana/pull/847))
- Prevent panic in Sift tool when pattern type assertion fails ([#834](https://github.com/grafana/mcp-grafana/pull/834))

## [0.13.1] - 2026-04-30

### Added

- Support PromQL queries against VictoriaMetrics datasources ([#767](https://github.com/grafana/mcp-grafana/pull/767))

### Fixed

- Include recording rules in datasource ruler listings for complete alerting rule visibility ([#819](https://github.com/grafana/mcp-grafana/pull/819))
- Propagate request context through OpenAPI convenience calls to ensure proper tracing and cancellation ([#822](https://github.com/grafana/mcp-grafana/pull/822))

## [0.13.0] - 2026-04-29

### Fixed

- Handle common LLM type mismatches (e.g. string vs number) in `alerting_manage_rules` to prevent tool call failures ([#816](https://github.com/grafana/mcp-grafana/pull/816))
- Convert ISO 8601 timestamps to epoch milliseconds in deeplink time ranges for correct Grafana URL generation ([#808](https://github.com/grafana/mcp-grafana/pull/808))
- Remove broken `search_logs` tool that was returning errors ([#815](https://github.com/grafana/mcp-grafana/pull/815))
- Normalize trailing slash in Grafana URL within `WithGrafanaConfig` to prevent malformed API requests ([#809](https://github.com/grafana/mcp-grafana/pull/809))
- Include on-behalf-of tokens in `fetchPublicURL` config so delegated identity works for public URL resolution ([#810](https://github.com/grafana/mcp-grafana/pull/810))
- Walk legacy dashboard rows (schemaVersion <= 14) in panel walkers so older dashboards are fully traversed ([#817](https://github.com/grafana/mcp-grafana/pull/817))

## [0.12.1] - 2026-04-28

### Added

- Support per-request Grafana configuration via context in HTTP RoundTrippers ([#805](https://github.com/grafana/mcp-grafana/pull/805))
- Optional `Logger` field on `GrafanaConfig` for structured logging ([#787](https://github.com/grafana/mcp-grafana/pull/787))

### Fixed

- Validate assertion timestamps as strings instead of `time.Time` to prevent type errors ([#793](https://github.com/grafana/mcp-grafana/pull/793))
- Trim trailing slash from Grafana URL during proxied tool discovery to avoid malformed requests ([#788](https://github.com/grafana/mcp-grafana/pull/788))

### Changed

- Use shared `BuildTransport` constructor in `fetchPublicURL` for consistent HTTP middleware ([#789](https://github.com/grafana/mcp-grafana/pull/789))

## [0.12.0] - 2026-04-23

### Added

- InfluxDB datasource support with both Flux and InfluxQL query languages ([#775](https://github.com/grafana/mcp-grafana/pull/775))
- Graphite datasource support with metric finding, query execution, and function discovery tools ([#741](https://github.com/grafana/mcp-grafana/pull/741))
- Support legacy `d-solo` render mode for panel image rendering ([#751](https://github.com/grafana/mcp-grafana/pull/751))
- Forward `Accept` header through API proxy for rendering requests ([#747](https://github.com/grafana/mcp-grafana/pull/747))

### Fixed

- Include full query data in alert rule get response, preserving datasource-specific fields ([#777](https://github.com/grafana/mcp-grafana/pull/777))
- Propagate trace context through OnCall, ClickHouse, and CloudWatch tools for end-to-end distributed tracing ([#769](https://github.com/grafana/mcp-grafana/pull/769))
- Register ephemeral sessions to fix horizontal scaling of proxied tools ([#754](https://github.com/grafana/mcp-grafana/pull/754))
- Encode Basic Auth credentials per RFC 7617 in proxied client ([#758](https://github.com/grafana/mcp-grafana/pull/758))
- Preserve datasource-specific model fields (e.g. Graphite `target`, classic conditions) during alert rule JSON round-tripping ([#730](https://github.com/grafana/mcp-grafana/pull/730))
- Include forwarded headers in client cache key to prevent cross-user cache collisions ([#768](https://github.com/grafana/mcp-grafana/pull/768))

### Changed

- Reduce tool schema token cost and response payload sizes for lower LLM token usage ([#734](https://github.com/grafana/mcp-grafana/pull/734))
- Standardize HTTP transport middleware via shared `BuildTransport()` constructor ([#771](https://github.com/grafana/mcp-grafana/pull/771))

### Security

- Reject embedded credentials in `X-Grafana-URL` header to prevent credential leakage ([#782](https://github.com/grafana/mcp-grafana/pull/782))
- Reject malformed `X-Grafana-URL` header instead of panicking ([#762](https://github.com/grafana/mcp-grafana/pull/762))
- Update Prometheus dependency to v0.311.2 to address security vulnerability ([#742](https://github.com/grafana/mcp-grafana/pull/742))

## [0.11.6] - 2026-04-09

### Added

- Apply on-behalf-of authentication headers in the Grafana client transport chain, enabling delegated identity for API requests ([#728](https://github.com/grafana/mcp-grafana/pull/728))

### Fixed

- Preserve dashboard identity fields (`id`, `uid`, `version`) in patch mode to prevent accidental dashboard duplication ([#722](https://github.com/grafana/mcp-grafana/pull/722))

## [0.11.5] - 2026-04-09

### Added

- Forward selected request headers (e.g. `Cookie`, `Authorization`) to Grafana in SSE and streamable-http modes, enabling SSO and ALB session cookie authentication ([#659](https://github.com/grafana/mcp-grafana/pull/659))
- Support optional `projectName` parameter for Cloud Monitoring datasources to query specific GCP projects ([#710](https://github.com/grafana/mcp-grafana/pull/710))
- Add `BaseTransport` field to `GrafanaConfig` for custom HTTP transport composition ([#726](https://github.com/grafana/mcp-grafana/pull/726))

### Fixed

- Extract Elasticsearch query field in alert rule summaries for accurate rule descriptions ([#714](https://github.com/grafana/mcp-grafana/pull/714))
- Clarify dashboard authoring guidance in tool descriptions to reduce LLM confusion ([#713](https://github.com/grafana/mcp-grafana/pull/713))

## [0.11.4] - 2026-04-02

### Added

- Pyroscope series query and unified query tool for profiling data exploration ([#672](https://github.com/grafana/mcp-grafana/pull/672))
- Generic Kubernetes-style API client for interacting with Grafana app platform resources ([#690](https://github.com/grafana/mcp-grafana/pull/690))
- `--session-idle-timeout-minutes` CLI flag to automatically close idle sessions ([#691](https://github.com/grafana/mcp-grafana/pull/691))
- Accept `X-Grafana-Service-Account-Token` header as an alternative authentication method ([#280](https://github.com/grafana/mcp-grafana/pull/280))
- Server-side filtering for `alerting_manage_rules` list operation to reduce response size ([#629](https://github.com/grafana/mcp-grafana/pull/629))
- Support categorized labels from Loki >= 3.0 for better label discovery ([#671](https://github.com/grafana/mcp-grafana/pull/671))
- Gemini CLI extension configuration for Grafana URL, token, and org ID settings ([#665](https://github.com/grafana/mcp-grafana/pull/665))
- Automatically fetch public URL from Grafana frontend settings for more accurate deep links ([#664](https://github.com/grafana/mcp-grafana/pull/664))
- Support PromQL queries against Google Cloud Monitoring datasources ([#647](https://github.com/grafana/mcp-grafana/pull/647))
- Query metadata and configurable result limit for `query_loki_logs` ([#654](https://github.com/grafana/mcp-grafana/pull/654))

### Fixed

- Missing parameters in create/update alert rule tools now correctly exposed ([#663](https://github.com/grafana/mcp-grafana/pull/663))
- Handle `text/*` content-type responses from Grafana API instead of failing on non-JSON responses ([#694](https://github.com/grafana/mcp-grafana/pull/694))
- Prevent memory leaks in streamable-http mode by properly cleaning up resources ([#685](https://github.com/grafana/mcp-grafana/pull/685))
- Fallback between `/resources` and `/proxy` datasource endpoints for broader datasource compatibility ([#562](https://github.com/grafana/mcp-grafana/pull/562))
- Warn when org ID is missing instead of silently discarding the parameter ([#678](https://github.com/grafana/mcp-grafana/pull/678))
- Support multi-value dashboard variables in `get_panel_image` ([#677](https://github.com/grafana/mcp-grafana/pull/677))
- Return actionable errors for unsupported JSONPath syntax in dashboard patch operations ([#675](https://github.com/grafana/mcp-grafana/pull/675))
- Convert Prometheus POST requests to GET for compatibility with datasources that don't support POST ([#633](https://github.com/grafana/mcp-grafana/pull/633))
- Fix `generate_deeplink` for explore resource type ([#644](https://github.com/grafana/mcp-grafana/pull/644))
- Prevent bare boolean JSON Schema values that caused errors with some LLM providers ([#597](https://github.com/grafana/mcp-grafana/pull/597))
- Prevent nil pointer crash in `get_dashboard_panel_queries` ([#661](https://github.com/grafana/mcp-grafana/pull/661))

### Changed

- Enhance `ConvertTool` with flexible integer conversion for more robust type handling ([#631](https://github.com/grafana/mcp-grafana/pull/631))
- Use end time for Prometheus instant queries instead of defaulting to current time ([#683](https://github.com/grafana/mcp-grafana/pull/683))

### Security

- Validate ClickHouse identifiers to prevent SQL injection ([#693](https://github.com/grafana/mcp-grafana/pull/693))

## [0.11.3] - 2026-03-12

### Added

- Support panel filtering and template variable substitution in `get_dashboard_panel_queries` for more targeted query extraction ([#539](https://github.com/grafana/mcp-grafana/pull/539))
- New `alerting_manage_routing` tool for managing notification policies, contact points, and time intervals in a single unified tool ([#618](https://github.com/grafana/mcp-grafana/pull/618))
- Add `accountId` parameter to CloudWatch tools for cross-account monitoring support ([#616](https://github.com/grafana/mcp-grafana/pull/616))

### Fixed

- Add `OrgIDRoundTripper` to the Grafana client transport chain so organization ID is correctly sent on all requests ([#649](https://github.com/grafana/mcp-grafana/pull/649))

### Changed

- Consolidate alerting rule tools into a single `alerting_manage_rules` tool for simpler discovery ([#619](https://github.com/grafana/mcp-grafana/pull/619))
- Use typed struct for alert query parameters instead of untyped `models.AlertQuery` ([#630](https://github.com/grafana/mcp-grafana/pull/630))
- Add server-side filtering support to alerting client for more efficient rule queries (Grafana 10.0+) ([#612](https://github.com/grafana/mcp-grafana/pull/612))

## [0.11.2] - 2026-02-24

### Changed

- Optimize Docker builds with Go cross-compilation for faster multi-platform image builds ([#600](https://github.com/grafana/mcp-grafana/pull/600))
- Fix Python wheel subpackage build to use correct `--package-path` flag ([#601](https://github.com/grafana/mcp-grafana/pull/601))

## [0.11.1] - 2026-02-24

### Added

- New `run_panel_query` tool that executes dashboard panel queries directly, with support for Prometheus, Loki, ClickHouse, and CloudWatch datasources, template variable substitution, Grafana macro expansion, and batch multi-panel queries ([#542](https://github.com/grafana/mcp-grafana/pull/542))

### Changed

- Merge near-duplicate MCP tools to reduce overall tool count, making it easier for LLMs to select the right tool ([#596](https://github.com/grafana/mcp-grafana/pull/596))

## [0.11.0] - 2026-02-19

### Added

- Elasticsearch datasource support with Lucene and Query DSL syntax, time range filtering, and configurable result limits ([#424](https://github.com/grafana/mcp-grafana/pull/424))
- CloudWatch datasource support with namespace, metric, and dimension discovery tools plus a guided query workflow ([#536](https://github.com/grafana/mcp-grafana/pull/536))

### Fixed

- Support standard HTTP proxy environment variables (`HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY`) for connecting through corporate proxies ([#578](https://github.com/grafana/mcp-grafana/pull/578))

## [0.10.0] - 2026-02-12

### Added

- ClickHouse datasource support ([#535](https://github.com/grafana/mcp-grafana/pull/535))
- `get_query_examples` tool for retrieving query examples from datasources ([#538](https://github.com/grafana/mcp-grafana/pull/538))
- `query_prometheus_histogram` tool for histogram percentile queries with automatic `histogram_quantile` PromQL generation ([#537](https://github.com/grafana/mcp-grafana/pull/537))
- Pagination support for `list_datasources` and `search_dashboards` tools with configurable limit/offset ([#543](https://github.com/grafana/mcp-grafana/pull/543))
- Custom HTTP headers support via `GRAFANA_EXTRA_HEADERS` environment variable for custom auth schemes and reverse proxy integration ([#522](https://github.com/grafana/mcp-grafana/pull/522))
- Prometheus metrics and OpenTelemetry instrumentation ([#506](https://github.com/grafana/mcp-grafana/pull/506))
- Alpine-based Docker image variants (`:alpine` and `:x.y.z-alpine` tags) for smaller image size (~74MB vs ~147MB) ([#568](https://github.com/grafana/mcp-grafana/pull/568))
- Support for `remove` operation on dashboard array elements by index ([#564](https://github.com/grafana/mcp-grafana/pull/564))

### Fixed

- `update_dashboard` tool descriptions and error messages improved to reduce LLM misuse ([#570](https://github.com/grafana/mcp-grafana/pull/570))
- Trim whitespace from dashboard patch operation paths ([#565](https://github.com/grafana/mcp-grafana/pull/565))
- DeepEval MCP evaluation for e2e tests ([#516](https://github.com/grafana/mcp-grafana/pull/516))

### Security

- Upgrade Docker base image packages to resolve critical OpenSSL CVE-2025-15467 (CVSS 9.8) ([#551](https://github.com/grafana/mcp-grafana/pull/551))

[1.3.0]: https://github.com/grafana/mcp-grafana/compare/v1.2.0...v1.3.0
[1.2.0]: https://github.com/grafana/mcp-grafana/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/grafana/mcp-grafana/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/grafana/mcp-grafana/compare/v0.17.2...v1.0.0
[0.17.2]: https://github.com/grafana/mcp-grafana/compare/v0.17.1...v0.17.2
[0.17.1]: https://github.com/grafana/mcp-grafana/compare/v0.17.0...v0.17.1
[0.17.0]: https://github.com/grafana/mcp-grafana/compare/v0.16.0...v0.17.0
[0.16.0]: https://github.com/grafana/mcp-grafana/compare/v0.15.2...v0.16.0
[0.15.2]: https://github.com/grafana/mcp-grafana/compare/v0.15.1...v0.15.2
[0.15.1]: https://github.com/grafana/mcp-grafana/compare/v0.15.0...v0.15.1
[0.15.0]: https://github.com/grafana/mcp-grafana/compare/v0.14.0...v0.15.0
[0.14.0]: https://github.com/grafana/mcp-grafana/compare/v0.13.1...v0.14.0
[0.13.1]: https://github.com/grafana/mcp-grafana/compare/v0.13.0...v0.13.1
[0.13.0]: https://github.com/grafana/mcp-grafana/compare/v0.12.1...v0.13.0
[0.12.1]: https://github.com/grafana/mcp-grafana/compare/v0.12.0...v0.12.1
[0.12.0]: https://github.com/grafana/mcp-grafana/compare/v0.11.6...v0.12.0
[0.11.6]: https://github.com/grafana/mcp-grafana/compare/v0.11.5...v0.11.6
[0.11.5]: https://github.com/grafana/mcp-grafana/compare/v0.11.4...v0.11.5
[0.11.4]: https://github.com/grafana/mcp-grafana/compare/v0.11.3...v0.11.4
[0.11.3]: https://github.com/grafana/mcp-grafana/compare/v0.11.2...v0.11.3
[0.11.2]: https://github.com/grafana/mcp-grafana/compare/v0.11.1...v0.11.2
[0.11.1]: https://github.com/grafana/mcp-grafana/compare/v0.11.0...v0.11.1
[0.11.0]: https://github.com/grafana/mcp-grafana/compare/v0.10.0...v0.11.0
[0.10.0]: https://github.com/grafana/mcp-grafana/compare/v0.9.0...v0.10.0
